@media(max-width: 1024px) {
    #menu-icon {
        display: block;
    }
    .navbar {
        position: absolute;
        top: 100%;
        right: 0;
        width: 50%;
        padding: 1rem 3rem;
        background-color: rgba(0, 0, 0, 0.8);
        border-left: 2px solid var(--main-color);
    }
}